import React from 'react';
import Link from 'next/link';
import Head from 'next/head';
import Image from 'next/image';
import { blogData, BlogPost } from '../../data/blogData';

const BlogCard = ({ post }: { post: BlogPost }) => (
  <Link href={`/blog/${post.slug}`} passHref>
    <div className="bg-gray-100 dark:bg-gray-800/50 rounded-lg overflow-hidden transition-all duration-300 ease-in-out hover:-translate-y-1 hover:shadow-lg hover:shadow-blue-500/30 cursor-pointer">
      {post.imageUrl && (
        <div className="relative w-full h-48">
          <Image
            src={post.imageUrl}
            alt={post.title}
            layout="fill"
            objectFit="cover"
            loading="lazy"
          />
        </div>
      )}
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-2">{post.title}</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">{new Date(post.date).toLocaleDateString()}</p>
        <p className="text-gray-700 dark:text-gray-300">{post.excerpt}</p>
      </div>
    </div>
  </Link>
);

const BlogPage = () => {
  // Blog yazılarını tarihe göre sırala (en yeni en üstte)
  const sortedPosts = [...blogData].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <>
      <Head>
        <title>Blog - Eren Özaltın</title>
        <meta name="description" content="Eren Özaltın'ın kişisel blogu" />
      </Head>
      <div className="space-y-8">
        <h1 className="text-4xl font-extrabold text-center">Blog</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sortedPosts.map((post) => (
            <BlogCard key={post.slug} post={post} />
          ))}
        </div>
      </div>
    </>
  );
};

export default BlogPage; 