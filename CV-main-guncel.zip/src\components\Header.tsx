import React from 'react';
import { FaMoon, FaSun } from 'react-icons/fa';
import { useTheme } from 'next-themes';
import Link from 'next/link';
import { useAuth } from '@/hooks/useAuth';

// Admin e-postaları - Bu listeyi admin sayfasıyla senkronize tutun
const allowedAdmins = ["eren.ozaltin@test.com", "admin@example.com"];

const ThemeChanger = () => {
  const { theme, setTheme } = useTheme();

  return (
    <button
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      className="bg-gray-200 dark:bg-gray-800 p-2 rounded-full text-gray-800 dark:text-gray-200"
      aria-label="Toggle Dark Mode"
    >
      {theme === 'dark' ? <FaSun /> : <FaMoon />}
    </button>
  );
};

const Header = () => {
  const { user } = useAuth();

  return (
    // Main header component
    <header className="container mx-auto px-4 max-w-4xl py-6 mb-8">
      <div className="flex justify-between items-center">
        <Link href="/" passHref>
          <span className="font-bold text-2xl cursor-pointer hover:text-blue-500 dark:hover:text-blue-400 transition-colors">
            Eren Özaltın
          </span>
        </Link>
        <nav className="flex items-center gap-6 text-lg">
          <Link href="/" passHref>
            <span className="cursor-pointer hover:text-blue-500 dark:hover:text-blue-400 transition-colors">CV</span>
          </Link>
          <Link href="/blog" passHref>
            <span className="cursor-pointer hover:text-blue-500 dark:hover:text-blue-400 transition-colors">Blog</span>
          </Link>
          
          {/* Admin linkini sadece yetkili kullanıcılara göster */}
          {user && allowedAdmins.includes(user.email || '') && (
             <Link href="/admin" passHref>
                <span className="cursor-pointer text-red-500 hover:text-red-400 font-bold transition-colors">Admin</span>
             </Link>
          )}

          <ThemeChanger />
        </nav>
      </div>
    </header>
  );
};

export default Header; 