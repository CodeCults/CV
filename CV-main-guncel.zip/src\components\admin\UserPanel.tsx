import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import toast from 'react-hot-toast';
import { FaUserShield, FaUserTimes, FaSync } from 'react-icons/fa';

interface User {
    uid: string;
    email?: string;
    displayName?: string;
    photoURL?: string;
    metadata: {
        creationTime?: string;
        lastSignInTime?: string;
    }
}

const UserPanel = () => {
    const { user } = useAuth();
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchUsers = async () => {
        if (!user) return;
        setLoading(true);
        try {
            const idToken = await user.getIdToken();
            const response = await fetch('/api/users', {
                headers: {
                    'Authorization': `Bearer ${idToken}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Kullanıcılar alınamadı.');
            }
            
            const data = await response.json();
            setUsers(data.users);
        } catch (error: any) {
            toast.error(`Hata: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, [user]);
    
    // TODO: Engelleme/Engeli kaldırma fonksiyonları eklenecek
    const handleBlockUser = (uid: string) => {
        toast.error('Bu özellik henüz aktif değil.');
        console.log("Block user:", uid);
    };

    const handleUnblockUser = (uid: string) => {
        toast.error('Bu özellik henüz aktif değil.');
        console.log("Unblock user:", uid);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white">Kullanıcı Yönetimi</h2>
                <button onClick={fetchUsers} disabled={loading} className="p-2 rounded-full hover:bg-gray-700 transition-colors disabled:opacity-50">
                    <FaSync className={loading ? 'animate-spin' : ''} />
                </button>
            </div>
            
            {loading ? (
                <p>Kullanıcılar yükleniyor...</p>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {users.map((u) => (
                        <div key={u.uid} className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                            <div className="flex items-center gap-4">
                                <img src={u.photoURL || '/profile-placeholder.jpg'} alt="avatar" className="w-12 h-12 rounded-full" />
                                <div className="overflow-hidden">
                                    <p className="font-bold truncate" title={u.displayName}>{u.displayName || 'İsimsiz'}</p>
                                    <p className="text-xs text-gray-400 truncate" title={u.email}>{u.email}</p>
                                </div>
                            </div>
                            <div className="text-xs text-gray-500 mt-3 space-y-1">
                                <p><strong>Kayıt:</strong> {new Date(u.metadata.creationTime!).toLocaleDateString()}</p>
                                <p><strong>Son Giriş:</strong> {new Date(u.metadata.lastSignInTime!).toLocaleDateString()}</p>
                            </div>
                            <div className="flex gap-2 mt-4 border-t border-gray-700 pt-3">
                                <button onClick={() => handleBlockUser(u.uid)} className="flex-1 bg-red-600 hover:bg-red-700 text-white px-3 py-1 text-xs rounded flex items-center justify-center gap-1">
                                    <FaUserTimes /> Engelle
                                </button>
                                 <button onClick={() => handleUnblockUser(u.uid)} className="flex-1 bg-green-600 hover:bg-green-700 text-white px-3 py-1 text-xs rounded flex items-center justify-center gap-1">
                                    <FaUserShield /> Engeli Kaldır
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default UserPanel; 