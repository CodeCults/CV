import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { PostData } from './BlogPanel';
import { CommentData } from '../Comment';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { FaFileAlt, FaComments, FaUsers } from 'react-icons/fa';

interface User {
    uid: string;
}

const DashboardPanel = () => {
    const [posts, setPosts] = useState<PostData[]>([]);
    const [comments, setComments] = useState<CommentData[]>([]);
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Yazıları, yorumları ve kullanıcıları (API'dan) çekmek için dinleyiciler
        const unsubPosts = onSnapshot(query(collection(db, 'posts')), snapshot => {
            setPosts(snapshot.docs.map(doc => doc.data() as PostData));
        });
        
        const unsubComments = onSnapshot(query(collection(db, 'comments')), snapshot => {
            setComments(snapshot.docs.map(doc => doc.data() as CommentData));
        });

        // Kullanıcıları API'dan çek (Bu kısım UserPanel'den alınabilir, şimdilik temsili)
        // Gerçek uygulamada, kullanıcı sayısını almak için ayrı bir API endpoint'i daha verimli olabilir.
        // Şimdilik temsili olarak boş bırakıyoruz, gerçek kullanıcı sayısı UserPanel'de.
        setLoading(false); 

        return () => {
            unsubPosts();
            unsubComments();
        };
    }, []);

    const recentPostsData = useMemo(() => {
        const data: { [key: string]: number } = {};
        for (let i = 6; i >= 0; i--) {
            const d = new Date();
            d.setDate(d.getDate() - i);
            data[d.toISOString().split('T')[0]] = 0;
        }
        posts.forEach(post => {
            if (post.createdAt?.toDate) {
                const date = post.createdAt.toDate().toISOString().split('T')[0];
                if (data[date] !== undefined) {
                    data[date]++;
                }
            }
        });
        return Object.entries(data).map(([name, value]) => ({ name, 'Yazı Sayısı': value }));
    }, [posts]);

    const topPostsData = useMemo(() => {
        const commentCounts = comments.reduce((acc, comment) => {
            acc[comment.postSlug] = (acc[comment.postSlug] || 0) + 1;
            return acc;
        }, {} as { [key: string]: number });

        return Object.entries(commentCounts)
            .sort(([, a], [, b]) => b - a)
            .slice(0, 5)
            .map(([name, Yorumlar]) => ({ name, Yorumlar }));
    }, [comments]);
    
    if (loading) return <p>İstatistikler yükleniyor...</p>;

    return (
        <div>
            <h2 className="text-3xl font-bold mb-8 text-white">Dashboard</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-gray-800 p-6 rounded-lg flex items-center gap-4">
                    <FaFileAlt className="text-4xl text-blue-400" />
                    <div>
                        <p className="text-gray-400">Toplam Yazı</p>
                        <p className="text-2xl font-bold">{posts.length}</p>
                    </div>
                </div>
                <div className="bg-gray-800 p-6 rounded-lg flex items-center gap-4">
                    <FaComments className="text-4xl text-green-400" />
                    <div>
                        <p className="text-gray-400">Toplam Yorum</p>
                        <p className="text-2xl font-bold">{comments.length}</p>
                    </div>
                </div>
                <div className="bg-gray-800 p-6 rounded-lg flex items-center gap-4">
                    <FaUsers className="text-4xl text-yellow-400" />
                    <div>
                        <p className="text-gray-400">Toplam Kullanıcı</p>
                        <p className="text-2xl font-bold">N/A</p> 
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-gray-800 p-6 rounded-lg">
                    <h3 className="font-bold mb-4">Son 7 Günlük Yazı Aktivitesi</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={recentPostsData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#4a5568" />
                            <XAxis dataKey="name" stroke="#a0aec0" />
                            <YAxis stroke="#a0aec0" />
                            <Tooltip contentStyle={{ backgroundColor: '#2d3748', border: 'none' }} />
                            <Legend />
                            <Line type="monotone" dataKey="Yazı Sayısı" stroke="#63b3ed" strokeWidth={2} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
                <div className="bg-gray-800 p-6 rounded-lg">
                    <h3 className="font-bold mb-4">En Çok Yorum Alan Yazılar</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={topPostsData} layout="vertical">
                            <CartesianGrid strokeDasharray="3 3" stroke="#4a5568" />
                            <XAxis type="number" stroke="#a0aec0" />
                            <YAxis type="category" dataKey="name" width={100} stroke="#a0aec0" tick={{ fontSize: 12 }} />
                            <Tooltip contentStyle={{ backgroundColor: '#2d3748', border: 'none' }} />
                            <Legend />
                            <Bar dataKey="Yorumlar" fill="#48bb78" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

export default DashboardPanel; 