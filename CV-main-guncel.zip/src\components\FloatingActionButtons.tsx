import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { FaArrowUp, FaArrowLeft } from 'react-icons/fa';

const FloatingActionButtons = () => {
    const router = useRouter();
    const [isVisible, setIsVisible] = useState(false);

    const toggleVisibility = () => {
        if (window.pageYOffset > 300) {
            setIsVisible(true);
        } else {
            setIsVisible(false);
        }
    };

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth',
        });
    };

    useEffect(() => {
        window.addEventListener('scroll', toggleVisibility);
        return () => {
            window.removeEventListener('scroll', toggleVisibility);
        };
    }, []);

    return (
        <>
            {/* Yukarı Çık Butonu */}
            {isVisible && (
                <button
                    onClick={scrollToTop}
                    aria-label="Yukarı Çık"
                    className="fixed bottom-4 right-4 z-50 bg-black/70 text-white rounded-full p-3 shadow-lg hover:bg-black/90 transition-all duration-300"
                >
                    <FaArrowUp />
                </button>
            )}
            {/* Geri Dön Butonu */}
            <button
                onClick={() => router.back()}
                aria-label="Geri Dön"
                className="fixed top-4 left-4 z-50 bg-black/70 text-white rounded-full p-3 shadow-lg hover:bg-black/90 transition-all duration-300"
            >
                <FaArrowLeft />
            </button>
        </>
    );
};

export default FloatingActionButtons; 