import React, { useState, useEffect } from 'react';
import { db, auth } from '../../lib/firebase';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import Comment, { CommentData } from './Comment';
import { useAuth } from '../hooks/useAuth';
import { useRouter } from 'next/router';
import { signOut } from 'firebase/auth';
import toast from 'react-hot-toast';
import { FaSignOutAlt } from 'react-icons/fa';

interface CommentSectionProps {
    postSlug: string;
}

const CommentSection = ({ postSlug }: CommentSectionProps) => {
    const [comments, setComments] = useState<CommentData[]>([]);
    const [text, setText] = useState('');
    const [loading, setLoading] = useState(true);
    const { user, loading: authLoading } = useAuth();
    const router = useRouter();

    useEffect(() => {
        const q = query(
            collection(db, 'comments'),
            where('postSlug', '==', postSlug),
            orderBy('createdAt', 'asc')
        );

        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const commentsData = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
            } as CommentData));
            setComments(commentsData);
            setLoading(false);
        });

        return () => unsubscribe();
    }, [postSlug]);

    const handleAddComment = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!text.trim() || !user) return;

        await addDoc(collection(db, 'comments'), {
            postSlug,
            userId: user.uid,
            userName: user.displayName || user.email?.split('@')[0] || "Anonim",
            userEmail: user.email,
            text,
            parentId: null,
            createdAt: serverTimestamp(),
            likes: [],
        });
        
        setText('');
        toast.success("Yorumunuz başarıyla gönderildi!");
    };

    const handleSignOut = async () => {
        await signOut(auth);
        toast.success("Başarıyla çıkış yaptınız.");
    };
    
    const topLevelComments = comments.filter(c => !c.parentId);

    return (
        <section className="mt-12 max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 pb-2 border-b-2 border-gray-700">Yorumlar ({comments.length})</h2>
            
            <div className="mb-8 bg-gray-800/50 p-6 rounded-lg">
                {authLoading ? (
                    <p>Yükleniyor...</p>
                ) : user ? (
                    <>
                        <div className="flex justify-between items-center mb-4">
                            <p className="font-semibold">
                                Yorum yapılıyor: <span className="text-blue-400">{user.displayName || user.email}</span>
                            </p>
                            <button onClick={handleSignOut} className="flex items-center gap-2 text-sm text-red-400 hover:text-red-600 transition">
                                <FaSignOutAlt />
                                Çıkış Yap
                            </button>
                        </div>
                        <form onSubmit={handleAddComment} className="space-y-4">
                            <textarea
                                value={text}
                                onChange={(e) => setText(e.target.value)}
                                placeholder="Yorumunuzu yazın..."
                                required
                                rows={4}
                                className="bg-gray-900 text-white border border-gray-700 rounded px-4 py-2 w-full"
                            />
                            <button type="submit" className="text-white bg-blue-600 hover:bg-blue-700 transition px-4 py-2 rounded-lg">
                                Gönder
                            </button>
                        </form>
                    </>
                ) : (
                     <p className="text-gray-400 italic text-center text-sm p-4">
                        Yorum yapmak için <a href={`/login?returnUrl=${router.asPath}`} className="text-blue-500 underline hover:text-blue-400">giriş yapmalısınız</a>.
                    </p>
                )}
            </div>

            {/* Yorum Listesi */}
            <div className="space-y-6">
                {loading ? (
                    <p className="text-center">Yorumlar yükleniyor...</p>
                ) : topLevelComments.length > 0 ? (
                    topLevelComments.map(comment => (
                        <Comment key={comment.id} comment={comment} allComments={comments} postSlug={postSlug} onReply={() => {}}/>
                    ))
                ) : (
                    <p className="text-center text-gray-500">Henüz yorum yapılmamış. İlk yorumu siz yapın!</p>
                )}
            </div>
        </section>
    );
};

export default CommentSection; 