import React, { useState } from 'react';
import { FaThumbsUp, FaSignOutAlt, FaHeart, FaReply, FaCrown } from 'react-icons/fa';
import { db, auth } from '../../lib/firebase';
import { doc, updateDoc, addDoc, collection, serverTimestamp, arrayUnion, arrayRemove } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { signOut } from 'firebase/auth';
import toast from 'react-hot-toast';

// Arayüzler
export interface CommentData {
    id: string;
    postSlug: string;
    userId: string; // Firebase Auth UID
    userName: string; // Firebase Auth displayName
    userEmail: string; // Firebase Auth email
    text: string;
    parentId?: string | null;
    createdAt: any;
    likes: string[]; // Beğenen kullanıcı/anonim ID'lerinin listesi
}

interface CommentProps {
    comment: CommentData;
    allComments: CommentData[];
    postSlug: string;
    onReply: (parentId: string, replyData: Omit<CommentData, 'id' | 'postSlug' | 'parentId' | 'createdAt' | 'likes'>) => void;
}

// Yorum Formu (Cevaplar için)
const ReplyForm = ({ parentId, postSlug, onAddReply }: { parentId: string, postSlug: string, onAddReply: () => void }) => {
    const { user } = useAuth();
    const [text, setText] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!text.trim() || !user) return;

        await addDoc(collection(db, 'comments'), {
            postSlug,
            userId: user.uid,
            userName: user.displayName || user.email?.split('@')[0] || "Anonim",
            userEmail: user.email,
            text,
            parentId,
            createdAt: serverTimestamp(),
            likes: [], // Başlangıçta boş dizi
        });
        toast.success("Cevabınız gönderildi!");
        onAddReply();
    };
    
    // Kullanıcı giriş yapmamışsa bu form hiç gösterilmez.
    if (!user) return null;

    return (
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
            <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Cevabınızı yazın..."
                required
                rows={3}
                className="bg-gray-900 text-white border border-gray-700 rounded px-3 py-2 w-full"
            />
            <button type="submit" className="text-sm text-white bg-blue-600 hover:bg-blue-700 transition px-3 py-1 rounded">
                Cevapla
            </button>
        </form>
    );
};

// Her tarayıcı için benzersiz ve kalıcı bir kullanıcı ID'si oluşturur veya alır.
const getAnonymousUserId = (): string => {
    let userId = localStorage.getItem('anonymousUserId');
    if (!userId) {
        userId = `anon_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
        localStorage.setItem('anonymousUserId', userId);
    }
    return userId;
};

const ownerEmail = "ozalti2n@gmail.com";

const Comment = ({ comment, allComments, postSlug }: CommentProps) => {
    const [isReplying, setIsReplying] = useState(false);
    const { user } = useAuth();

    // Beğeni için kullanılacak ID: Giriş yapmışsa user.uid, değilse anonim ID.
    const likeId = user ? user.uid : getAnonymousUserId();
    const isLiked = comment.likes?.includes(likeId);

    const handleLike = async () => {
        const commentRef = doc(db, 'comments', comment.id);
        
        if (isLiked) {
            await updateDoc(commentRef, {
                likes: arrayRemove(likeId)
            });
        } else {
            await updateDoc(commentRef, {
                likes: arrayUnion(likeId)
            });
        }
    };
    
    const childComments = allComments.filter(c => c.parentId === comment.id);

    return (
        <div className="bg-gray-800 text-white border border-gray-700 rounded-md p-4">
            <div className="flex justify-between items-start">
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-sm text-white">{comment.userName}</p>
                        {comment.userEmail === ownerEmail && (
                            <span className="bg-red-600 text-white text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                                <FaCrown size={10} />
                                OWNER
                            </span>
                        )}
                        <p className="text-xs text-gray-500">
                            {comment.createdAt?.toDate ? comment.createdAt.toDate().toLocaleString() : 'Az önce'}
                        </p>
                    </div>
                    <p className="text-gray-300">{comment.text}</p>
                </div>
                <div className="flex items-center gap-4 text-gray-400">
                    <button onClick={handleLike} className={`flex items-center gap-1 transition ${isLiked ? 'text-green-500' : 'text-gray-400 hover:text-green-500'}`}>
                        <FaThumbsUp />
                        <span>{comment.likes?.length || 0}</span>
                    </button>
                </div>
            </div>

            {user && (
                <div className="mt-3">
                    <button onClick={() => setIsReplying(!isReplying)} className="text-sm text-blue-400 hover:text-blue-600 transition">
                        {isReplying ? 'İptal' : 'Cevapla'}
                    </button>
                </div>
            )}

            {isReplying && (
                <ReplyForm 
                    parentId={comment.id} 
                    postSlug={postSlug} 
                    onAddReply={() => setIsReplying(false)}
                />
            )}

            {childComments.length > 0 && (
                <div className="ml-4 pl-4 border-l-2 border-gray-700 mt-4 space-y-4">
                    {childComments.map(child => (
                        <Comment key={child.id} comment={child} allComments={allComments} postSlug={postSlug} onReply={() => {}} />
                    ))}
                </div>
            )}
        </div>
    );
};

export default Comment; 