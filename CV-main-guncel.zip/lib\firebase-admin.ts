import * as admin from 'firebase-admin';

// Sunucu tarafında birden fazla app instance'ı oluşmasını engelle
if (!admin.apps.length) {
    // Servis hesabı anahtarını ortam değişkenlerinden güvenli bir şekilde al
    const serviceAccount = JSON.parse(
        process.env.FIREBASE_SERVICE_ACCOUNT_KEY as string
    );

    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
    });
}

export const authAdmin = admin.auth();
export const dbAdmin = admin.firestore(); 