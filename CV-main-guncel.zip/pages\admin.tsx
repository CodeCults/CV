import React, { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '@/hooks/useAuth';
import { collection, onSnapshot, orderBy, query, doc, deleteDoc, updateDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { CommentData } from '@/components/Comment';
import toast from 'react-hot-toast';
import { FaTachometerAlt, FaComments, FaPen, FaUsers } from 'react-icons/fa';

// Admin Paneli Bileşenlerini Dinamik Olarak Yükle
import dynamic from 'next/dynamic';
const DashboardPanel = dynamic(() => import('@/components/admin/DashboardPanel'));
const CommentsPanel = dynamic(() => import('@/components/admin/CommentsPanel'));
const BlogPanel = dynamic(() => import('@/components/admin/BlogPanel'));
const UserPanel = dynamic(() => import('@/components/admin/UserPanel'));

// Yetkili admin e-postaları
const allowedAdmins = ["eren.ozaltin@test.com", "admin@example.com", "ozalti2n@gmail.com"];

type Tab = 'dashboard' | 'comments' | 'blog' | 'users';

const AdminPage = () => {
    const { user, loading } = useAuth();
    const router = useRouter();
    const [activeTab, setActiveTab] = useState<Tab>('dashboard');

    const isAdmin = useMemo(() => {
        if (!user) return false;
        return allowedAdmins.includes(user.email?.toLowerCase() || '');
    }, [user]);

    useEffect(() => {
        if (loading) return;
        if (!isAdmin) {
            toast.error("Bu sayfaya erişim yetkiniz yok.");
            router.push('/');
        }
    }, [user, loading, isAdmin, router]);

    const renderPanel = () => {
        switch (activeTab) {
            case 'dashboard': return <DashboardPanel />;
            case 'comments': return <CommentsPanel />;
            case 'blog': return <BlogPanel />;
            case 'users': return <UserPanel />;
            default: return <DashboardPanel />;
        }
    };

    if (loading || !isAdmin) {
        return <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">Yetki kontrolü yapılıyor...</div>;
    }

    const tabs = [
        { id: 'dashboard', label: 'Dashboard', icon: FaTachometerAlt },
        { id: 'comments', label: 'Yorumlar', icon: FaComments },
        { id: 'blog', label: 'Blog Yazıları', icon: FaPen },
        { id: 'users', label: 'Kullanıcılar', icon: FaUsers },
    ];

    return (
        <div className="flex min-h-screen bg-gray-900 text-gray-200">
            <aside className="w-64 bg-gray-800 p-4 space-y-4 flex flex-col">
                <div className="text-center">
                    <h1 className="text-2xl font-bold text-white">Admin Paneli</h1>
                    <p className="text-green-400 text-xs italic mt-1">Hoş geldin, {user?.displayName || user?.email}</p>
                </div>
                <nav className="flex flex-col space-y-2 mt-4">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as Tab)}
                            className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors w-full text-left ${
                                activeTab === tab.id
                                    ? 'bg-blue-600 text-white shadow-lg'
                                    : 'hover:bg-gray-700'
                            }`}
                        >
                            <tab.icon />
                            <span>{tab.label}</span>
                        </button>
                    ))}
                </nav>
            </aside>
            <main className="flex-1 p-8 overflow-y-auto">
                <div className="max-w-7xl mx-auto">
                    {renderPanel()}
                </div>
            </main>
        </div>
    );
};

// Bu sayfanın Layout'a dahil olmamasını sağlıyoruz, çünkü kendi layout'u var.
AdminPage.getLayout = function getLayout(page: React.ReactElement) {
  return page;
};

export default AdminPage; 