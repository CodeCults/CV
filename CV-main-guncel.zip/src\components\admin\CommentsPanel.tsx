import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, orderBy, query, doc, deleteDoc, updateDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { CommentData } from '@/components/Comment';
import toast from 'react-hot-toast';
import { FaTrash, FaUndo, FaSearch } from 'react-icons/fa';

const CommentsPanel = () => {
    const [comments, setComments] = useState<CommentData[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const q = query(collection(db, 'comments'), orderBy('createdAt', 'desc'));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const commentsData = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            } as CommentData));
            setComments(commentsData);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const filteredComments = useMemo(() => {
        if (!searchTerm) return comments;
        const lowercasedFilter = searchTerm.toLowerCase();
        return comments.filter(comment =>
            comment.text.toLowerCase().includes(lowercasedFilter) ||
            comment.userEmail.toLowerCase().includes(lowercasedFilter) ||
            comment.postSlug.toLowerCase().includes(lowercasedFilter)
        );
    }, [comments, searchTerm]);

    const handleDeleteComment = async (commentId: string) => {
        if (!confirm('Bu yorumu silmek istediğinizden emin misiniz?')) return;
        try {
            await deleteDoc(doc(db, 'comments', commentId));
            toast.success('Yorum başarıyla silindi.');
        } catch (error) {
            toast.error('Yorum silinirken bir hata oluştu.');
        }
    };

    const handleResetLikes = async (commentId: string) => {
        if (!confirm('Bu yorumun beğenilerini sıfırlamak istediğinizden emin misiniz?')) return;
        try {
            await updateDoc(doc(db, 'comments', commentId), { likes: [] });
            toast.success('Beğeniler başarıyla sıfırlandı.');
        } catch (error) {
            toast.error('Beğeniler sıfırlanırken bir hata oluştu.');
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-6 text-white">Yorum Yönetimi</h2>
            
            <div className="mb-6 relative">
                <input
                    type="text"
                    placeholder="Yorum, e-posta veya slug ile ara..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-gray-700 text-white border border-gray-600 rounded-lg py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            </div>

            {loading ? (
                <p>Yorumlar yükleniyor...</p>
            ) : (
                <div className="space-y-4">
                    {filteredComments.map((comment) => (
                        <div key={comment.id} className="bg-gray-800 p-4 rounded-xl border border-gray-700 space-y-3 transition-shadow hover:shadow-lg">
                            <p className="text-white">{comment.text}</p>
                            <div className="border-t border-gray-700 pt-3">
                                <div className="flex justify-between items-center">
                                    <div className="text-xs text-gray-400 space-y-1">
                                        <p><strong>Kullanıcı:</strong> {comment.userName} ({comment.userEmail})</p>
                                        <p><strong>Yazı:</strong> <a href={`/blog/${comment.postSlug}`} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">{comment.postSlug}</a></p>
                                        <p><strong>Tarih:</strong> {comment.createdAt?.toDate ? comment.createdAt.toDate().toLocaleString() : 'N/A'}</p>
                                        <p><strong>Beğeni:</strong> {comment.likes?.length || 0}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <button onClick={() => handleResetLikes(comment.id)} title="Beğeniyi Sıfırla" className="p-2 rounded-full hover:bg-gray-700 transition-colors">
                                            <FaUndo className="text-yellow-500" />
                                        </button>
                                        <button onClick={() => handleDeleteComment(comment.id)} title="Yorumu Sil" className="p-2 rounded-full hover:bg-gray-700 transition-colors">
                                            <FaTrash className="text-red-500" />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default CommentsPanel; 