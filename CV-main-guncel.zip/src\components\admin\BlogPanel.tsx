import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, orderBy, query, doc, addDoc, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import toast from 'react-hot-toast';
import dynamic from 'next/dynamic';
import { FaPlus, FaEdit, FaTrash, FaSave } from 'react-icons/fa';
import { useAuth } from '@/hooks/useAuth';

// Markdown editörünü sadece client-side'da render et
const SimpleMDE = dynamic(() => import('react-simplemde-editor'), { ssr: false });

export interface PostData {
    id: string;
    title: string;
    slug: string;
    content: string;
    tags: string[];
    status: 'published' | 'draft';
    createdAt: any;
    authorId: string;
}

const BlogPanel = () => {
    const { user } = useAuth();
    const [posts, setPosts] = useState<PostData[]>([]);
    const [isEditing, setIsEditing] = useState<PostData | null>(null);
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [status, setStatus] = useState<'published' | 'draft'>('draft');

    useEffect(() => {
        const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const postsData = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            } as PostData));
            setPosts(postsData);
        });
        return () => unsubscribe();
    }, []);

    const createSlug = (title: string) => {
        return title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    };

    const handleEdit = (post: PostData) => {
        setIsEditing(post);
        setTitle(post.title);
        setContent(post.content);
        setStatus(post.status);
    };
    
    const handleCancel = () => {
        setIsEditing(null);
        setTitle('');
        setContent('');
        setStatus('draft');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !content || !user) return;
        
        const slug = createSlug(title);
        const postData = {
            title,
            slug,
            content,
            status,
            tags: [], // Şimdilik boş
            authorId: user.uid,
        };

        try {
            if (isEditing) {
                const postRef = doc(db, 'posts', isEditing.id);
                await updateDoc(postRef, { ...postData, createdAt: isEditing.createdAt });
                toast.success('Yazı başarıyla güncellendi.');
            } else {
                await addDoc(collection(db, 'posts'), { ...postData, createdAt: serverTimestamp() });
                toast.success('Yazı başarıyla oluşturuldu.');
            }
            handleCancel();
        } catch (error) {
            toast.error('İşlem sırasında bir hata oluştu.');
        }
    };
    
    const handleDelete = async (postId: string) => {
        if (!confirm('Bu yazıyı kalıcı olarak silmek istediğinizden emin misiniz?')) return;
        try {
            await deleteDoc(doc(db, 'posts', postId));
            toast.success('Yazı başarıyla silindi.');
        } catch (error) {
            toast.error('Yazı silinirken bir hata oluştu.');
        }
    };

    if (isEditing) {
        return (
            <div>
                <h2 className="text-2xl font-bold mb-4">{isEditing.id ? 'Yazıyı Düzenle' : 'Yeni Yazı Oluştur'}</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Yazı Başlığı" className="w-full p-2 rounded bg-gray-700" required />
                    <SimpleMDE value={content} onChange={setContent} />
                    <select value={status} onChange={e => setStatus(e.target.value as 'published' | 'draft')} className="w-full p-2 rounded bg-gray-700">
                        <option value="draft">Taslak</option>
                        <option value="published">Yayınlandı</option>
                    </select>
                    <div className="flex gap-4">
                        <button type="submit" className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded flex items-center gap-2"><FaSave /> Kaydet</button>
                        <button type="button" onClick={handleCancel} className="bg-gray-600 hover:bg-gray-500 px-4 py-2 rounded">İptal</button>
                    </div>
                </form>
            </div>
        );
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Blog Yazıları</h2>
                <button onClick={() => setIsEditing({} as PostData)} className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded flex items-center gap-2"><FaPlus /> Yeni Yazı</button>
            </div>
            <div className="space-y-4">
                {posts.map(post => (
                    <div key={post.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
                        <div>
                            <h3 className="font-bold">{post.title}</h3>
                            <p className={`text-sm ${post.status === 'published' ? 'text-green-400' : 'text-yellow-400'}`}>{post.status}</p>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={() => handleEdit(post)} className="p-2 hover:bg-gray-700 rounded"><FaEdit /></button>
                            <button onClick={() => handleDelete(post.id)} className="p-2 hover:bg-gray-700 rounded"><FaTrash /></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default BlogPanel; 