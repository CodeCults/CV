import { GetServerSideProps } from 'next';
import Head from 'next/head';
import React from 'react';
import dynamic from 'next/dynamic';
import { dbAdmin } from '@/lib/firebase-admin';
import { PostData } from '@/components/admin/BlogPanel';
import { remark } from 'remark';
import html from 'remark-html';

// Yorumlar bileşenini dinamik olarak ve SSR olmadan yükle
const CommentSection = dynamic(() => import('@/components/CommentSection'), {
  ssr: false,
  loading: () => <p className="text-center mt-8">Yorumlar yükleniyor...</p>,
});

interface PostPageProps {
  post: PostData;
  contentHtml: string;
}

const PostPage = ({ post, contentHtml }: PostPageProps) => {
  if (!post) {
    return <p>Yazı bulunamadı.</p>;
  }

  return (
    <>
      <Head>
        <title>{`${post.title} - Eren Özaltın`}</title>
        <meta name="description" content={post.content.substring(0, 150)} />
      </Head>
      <article className="prose prose-lg dark:prose-invert mx-auto mb-12">
        <h1>{post.title}</h1>
        <div dangerouslySetInnerHTML={{ __html: contentHtml }} />
      </article>

      <CommentSection postSlug={post.slug} />
    </>
  );
};

export const getServerSideProps: GetServerSideProps<PostPageProps> = async (context) => {
    const slug = context.params?.slug as string;

    if (!slug) {
        return { notFound: true };
    }

    try {
        const postsRef = dbAdmin.collection('posts');
        const snapshot = await postsRef.where('slug', '==', slug).where('status', '==', 'published').limit(1).get();

        if (snapshot.empty) {
            return { notFound: true };
        }

        const postDoc = snapshot.docs[0];
        const post = { id: postDoc.id, ...postDoc.data() } as PostData;
        
        // Convert timestamp
        if (post.createdAt && typeof post.createdAt.toDate === 'function') {
            post.createdAt = post.createdAt.toDate().toISOString();
        }
        
        const processedContent = await remark().use(html).process(post.content);
        const contentHtml = processedContent.toString();

        return {
            props: {
                post: JSON.parse(JSON.stringify(post)), // Serialize post data
                contentHtml,
            },
        };
    } catch (error) {
        console.error("Error fetching post:", error);
        return { notFound: true };
    }
};

export default PostPage; 