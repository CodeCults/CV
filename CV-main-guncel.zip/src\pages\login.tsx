import React, { useEffect } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { auth, provider } from '../../lib/firebase';
import { useAuth } from '../hooks/useAuth';
import { useRouter } from 'next/router';
import { FaGoogle } from 'react-icons/fa';

const LoginPage = () => {
    const { user, loading } = useAuth();
    const router = useRouter();

    useEffect(() => {
        if (!loading && user) {
            // Kullanıcı zaten giriş yapmışsa, geldiği sayfaya veya ana sayfaya yönlendir
            const returnUrl = router.query.returnUrl || '/';
            router.push(returnUrl as string);
        }
    }, [user, loading, router]);

    const signInWithGoogle = async () => {
        try {
            await signInWithPopup(auth, provider);
            // Başarılı giriş sonrası yönlendirme useEffect tarafından yapılacak
        } catch (error) {
            console.error("Google ile giriş sırasında hata oluştu:", error);
            // İsteğe bağlı: kullanıcıya bir bildirim gösterilebilir
        }
    };

    if (loading || user) {
        return <div className="text-center p-10">Yönlendiriliyorsunuz...</div>;
    }

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <div className="p-8 bg-gray-800 rounded-lg shadow-xl text-center">
                <h1 className="text-3xl font-bold mb-4">Giriş Yap</h1>
                <p className="text-gray-400 mb-6">Yorum yapmak için lütfen giriş yapın.</p>
                <button
                    onClick={signInWithGoogle}
                    className="flex items-center justify-center gap-3 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300 w-full"
                >
                    <FaGoogle />
                    <span>Google ile Giriş Yap</span>
                </button>
            </div>
        </div>
    );
};

export default LoginPage; 