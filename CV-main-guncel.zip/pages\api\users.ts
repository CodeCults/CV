import type { NextApiRequest, NextApiResponse } from 'next';
import { authAdmin } from '@/lib/firebase-admin';
import { UserRecord } from 'firebase-admin/auth';

// Bu e-posta listesi, admin paneliyle senkronize olmalıdır.
const allowedAdmins = ["eren.ozaltin@test.com", "admin@example.com", "ozalti2n@gmail.com"];

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method !== 'GET') {
        return res.status(405).json({ message: 'Method Not Allowed' });
    }

    try {
        const { authorization } = req.headers;
        if (!authorization || !authorization.startsWith('Bearer ')) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        
        const idToken = authorization.split('Bearer ')[1];
        const decodedToken = await authAdmin.verifyIdToken(idToken);
        
        // Token'ı gönderen kullanıcının admin listesinde olup olmadığını kontrol et
        if (!decodedToken.email || !allowedAdmins.includes(decodedToken.email)) {
             return res.status(403).json({ message: 'Forbidden: User is not an admin.' });
        }

        // Kullanıcı admin ise, tüm kullanıcıları listele
        const listUsersResult = await authAdmin.listUsers(1000); // Max 1000 kullanıcı
        const users = listUsersResult.users.map((userRecord: UserRecord) => {
            return {
                uid: userRecord.uid,
                email: userRecord.email,
                displayName: userRecord.displayName,
                photoURL: userRecord.photoURL,
                metadata: userRecord.metadata,
            };
        });

        res.status(200).json({ users });

    } catch (error: any) {
        console.error('Error listing users:', error);
        res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
} 