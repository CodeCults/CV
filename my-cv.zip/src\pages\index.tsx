import React from 'react'
import { FaEnvelope, FaPhone, FaMapMarkerAlt, FaGithub, FaLinkedin } from 'react-icons/fa'
import Image from 'next/image'
import Head from 'next/head'

export default function Home() {
  return (
    <>
      <Head>
        <title>Eren Özaltın - CV</title>
        <meta name="description" content="Eren Özaltın'ın kişisel CV sayfası" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <div className="min-h-screen bg-black relative">
        <div className="absolute inset-0 opacity-70">
          {/* Arka plan efekti burada olacak */}
        </div>
        
        {/* Hero Section */}
        <div className="bg-black/80 text-gray-50 py-20 relative">
          <div className="container mx-auto px-4 max-w-4xl relative z-10">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-48 h-48 relative rounded-full overflow-hidden border-4 border-gray-400 shadow-lg">
                <Image
                  src="/profile-placeholder.jpg"
                  alt="Eren Özaltın"
                  width={192}
                  height={192}
                  className="object-cover"
                  priority
                />
              </div>
              <div className="text-center md:text-left">
                <h1 className="text-5xl font-extrabold mb-4 text-white">
                  Eren Özaltın
                </h1>
                <p className="text-xl font-bold mb-6 text-white">
                  Web Geliştirici & Öğrenci
                </p>
                <p className="text-lg font-semibold opacity-90 max-w-2xl text-white">
                  16 yaşında, teknoloji tutkunu bir lise öğrencisiyim. Kodlama ve robotik alanlarında kendimi sürekli geliştiriyor, 
                  yeni teknolojileri öğrenmekten ve projeler üretmekten büyük keyif alıyorum.
                </p>
              </div>
            </div>
          </div>
        </div>

        <main className="container mx-auto px-4 max-w-4xl py-12 relative z-10">
          {/* About Section */}
          <section className="bg-black/70 backdrop-blur-md rounded-lg shadow-md p-8 mb-8">
            <h2 className="text-2xl font-bold text-white mb-4 pb-2 border-b border-gray-700">
              Hakkımda
            </h2>
            <p className="text-gray-300 leading-relaxed">
              Hızlı öğrenme yeteneğim ve problem çözme becerilerimle dikkat çekiyorum. 
              Kodlamaya olan tutkum ve sürekli kendimi geliştirme isteğim, her projede daha iyisini yapmam için beni motive ediyor.
            </p>
          </section>

          {/* Projects Section */}
          <section className="bg-black/70 backdrop-blur-md rounded-lg shadow-md p-8 mb-8">
            <h2 className="text-2xl font-bold text-white mb-4 pb-2 border-b border-gray-700">
              Projelerim
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-800/50 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-white mb-2">Kişisel Web Sitesi</h3>
                <p className="text-gray-300 mb-4">
                  Next.js ve Tailwind CSS kullanarak geliştirdiğim kişisel web sitem.
                </p>
                <div className="flex gap-2">
                  <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">Next.js</span>
                  <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">Tailwind CSS</span>
                </div>
              </div>
            </div>
          </section>

          {/* Contact Section */}
          <section className="bg-black/70 backdrop-blur-md rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold text-white mb-4 pb-2 border-b border-gray-700">
              İletişim
            </h2>
            <div className="flex flex-col space-y-4">
              <a href="mailto:ozalti2n@gmail.com" className="text-gray-300 hover:text-white flex items-center gap-3">
                <FaEnvelope className="w-5 h-5" />
                ozalti2n@gmail.com
              </a>
              <a href="https://github.com/CodeCults" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white flex items-center gap-3">
                <FaGithub className="w-5 h-5" />
                GitHub
              </a>
            </div>
          </section>
        </main>
      </div>
    </>
  )
} 